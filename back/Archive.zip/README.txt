just run 

bash curl_recognize.sh input_file_name output_file_name

i.e. 

bash curl_recognize.sh a.jpg output.txt